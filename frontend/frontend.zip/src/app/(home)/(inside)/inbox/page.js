'use client'
import { ChatLayout } from '@/app/components/chatComponents';
import Image from 'next/image';

export default function DashBoard() {
  return (
      <ChatLayout />
  );
}