'use client'

import { UpdateProfilePic } from "@/app/components/ProfilePic"

export default function UpdateProfilePicPage() {
    return (
        <UpdateProfilePic />
    )
}