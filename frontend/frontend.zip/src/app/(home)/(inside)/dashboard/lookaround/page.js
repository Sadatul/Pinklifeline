'use client'

import { LocationPage } from "@/app/components/nearByLocationPage"

export default function NearByPage() {
  return (
    <LocationPage />
  )
}