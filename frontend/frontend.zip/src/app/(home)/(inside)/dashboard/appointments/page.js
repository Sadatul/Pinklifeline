import { AppointmentsPage } from "@/app/components/AppointmentsPage";

export default function Page() {
    return <AppointmentsPage />
}