'use client'

import { AddPrescriptionPage } from "@/app/components/vault"

export default function AddToVaultPage(){
    return(
        <AddPrescriptionPage />
    )
}