'use client'

import { DoctorLivePrescriptionPage } from "@/app/components/livePrescription"

export default function PrescriptionPage(){
    return(
        <DoctorLivePrescriptionPage />
    )
}