'use client'

import { PatientLivePrescriptionPage } from "@/app/components/livePrescription"

export default function PrescriptionPage() {
    return (
        <PatientLivePrescriptionPage />
    )
}