'use client'

import AddWork from "@/app/components/worksComponents"

export default function AddWorkPage() {
    
    return (
        <AddWork />
    )
}