
'use client'
import Loading from "./components/loading";

export default function LoadingPage() {
    return <Loading />
}