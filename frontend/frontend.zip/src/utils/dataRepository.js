export function getMessages(roomId){
    return [
            {
                "sender": 3,
                "message": "afzal king",
                "timestamp": "2024-07-01T17:02:03",
                "type": "TEXT"
            },
            {
                "sender": 3,
                "message": "afzal king",
                "timestamp": "2024-07-01T17:02:46",
                "type": "TEXT"
            },
            {
                "sender": 2,
                "message": "afzal king",
                "timestamp": "2024-07-01T17:02:03",
                "type": "TEXT"
            },
            {
                "sender": 2,
                "message": "afzal king",
                "timestamp": "2024-07-01T17:02:46",
                "type": "TEXT"
            },
            {
                "sender": 3,
                "message": "afzal king",
                "timestamp": "2024-07-01T17:02:03",
                "type": "TEXT"
            },
            {
                "sender": 2,
                "message": "Last Message",
                "timestamp": "2024-07-01T17:02:46",
                "type": "TEXT"
            },

        ];

}


